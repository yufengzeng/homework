#ifndef __RTRF_H__
#define __RTRF_H__


#include  "mem.h"
#include  "os_type.h"
#include  "osapi.h"
#include  "driver/uart.h"


/**
 * Size of the buffer used to receive uart data
 */
#define FIFOLEN  250  	


/**Action type list*/
enum FrameType{	
         RFRT_RETURN_RESPOND  = 0xA0, /* shake respones               ESP8266 <- ->Mcu*/
         RFRT_LEARN_CMD       = 0xA1, /* begin leanr                  ESP8266  ->  Mcu*/
         RFRT_TIMEOUT         = 0xA2, /* learning timeout             ESP8266  <-  Mcu*/
         RFRT_LEARN_OK        = 0xA3, /* learning sucess              ESP8266  <-  Mcu*/
         RFRT_UPLOAD          = 0xA4, /* receive keyvalue and upload  ESP8266  <-  Mcu*/
         RFRT_EMIT_VALUE      = 0xA5, /* begin emit keyvale           ESP8266  ->  Mcu*/
         RFRT_ERROR_TYPE
};

/**
 * Record a frame's basic info.
 * Include Action Type, Tysn,Tlow,Thigh,and KeyValue.
 * @author Zeng yufeng.
 */ 
 typedef struct{
       uint8      actType;             
       uint16     tysn;
       uint16     tlow;
       uint16     thigh;
       uint8      dataArrar[3];  
 }RfrtInfoFrame;

 
 
/**System parameter initialization. the function must be called firest*/ 
void ICACHE_FLASH_ATTR rfrtInit(void);

/**
 * Regist the learn finish callback fuction.
 */ 
void ICACHE_FLASH_ATTR rfrtRegistLearnCallback(void (*learnCB)(RfrtInfoFrame));
 
/**
 * Regist the learn timeout callback fuction.
 */  
void ICACHE_FLASH_ATTR rfrtRegistTimeoutCallback(void (*timeoutCB)(void));
 
/**
 * Regist the receive keyvalue callback fuction.
 */  
void ICACHE_FLASH_ATTR rfrtRegistRecvKeyValueCallback(void (*recvKeyValueCB)(RfrtInfoFrame));

/**
 * Regist the Normal response callback fuction.
 */ 
void ICACHE_FLASH_ATTR rfrtRegistNormalResponCallback(void (*normalResponCB)(void));

 
/**
 *send command to MCU for Learn;
 */ 
void ICACHE_FLASH_ATTR rfrtLearnAction(void);
 
/**
 * send data to MCU for Emit;
 */ 
void ICACHE_FLASH_ATTR rfrtEmitKeyValue(RfrtInfoFrame);

/**
 *Extract information from uart frame;
 *pdata point to the head of frame, datalen: data length;
 */
void ICACHE_FLASH_ATTR rfrtDealRecvUartData(uint8*pdata,uint16 datalen);

 



#endif

