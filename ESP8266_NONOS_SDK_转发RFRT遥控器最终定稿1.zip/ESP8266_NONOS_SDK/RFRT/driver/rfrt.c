#include "rfrt.h"


#define MAX_FRAME_TYPE   6  


typedef struct 
{
    uint16     fifoBuffSize;
    uint8      pFifoBuff[FIFOLEN +1];  
    uint16     inPos;  
    uint16     outPos;  
}rfrtBuff;


rfrtBuff    fifoBuffer;
const uint8 FRAME_HEAD =  0xAA;
const uint8 FRAME_TAIL =  0x55;

const struct rfrtFrame
{
    uint8 frameType;
    uint8 framelength;
}rfrtFrameProp[MAX_FRAME_TYPE] =
{   
    {RFRT_RETURN_RESPOND,3},
    {RFRT_LEARN_CMD,     3},
    {RFRT_TIMEOUT,       3},
    {RFRT_LEARN_OK,      12},
    {RFRT_UPLOAD,        12},
    {RFRT_EMIT_VALUE,    12}
};



struct structNormalRespon
{
    void(*rfrtNormalResponCB)(void);
}rfrtNormalRespon;

struct structTimeOut
{
    void(*rfrtTimeOutCB)(void);
}rfrtTimeOut;



struct structLearn
{
    void(*rfrtLearnOkCB)(RfrtInfoFrame);
}rfrtLearn;


struct structRecvKeyValue
{
    void(*rfrtRecvValueCB)(RfrtInfoFrame);
}rfrtRecvKeyValue;


LOCAL uint8  ICACHE_FLASH_ATTR   rfrtGetFrameLen(uint8 frameType);
LOCAL void   ICACHE_FLASH_ATTR   rfrtAnalysisFrame(uint8* dataptr,uint16 datalen);
LOCAL bool   ICACHE_FLASH_ATTR   rfrtAddDataToFifo(uint8* pdata, uint16 datalen);
LOCAL uint8  ICACHE_FLASH_ATTR   rfrtCheckCorrectFrame(uint8*str,uint16 remainSpc);
LOCAL uint8* ICACHE_FLASH_ATTR   rfrtStrChr(uint8*str,uint16 strlen,uint8 chr);
LOCAL void   ICACHE_FLASH_ATTR   rfrtActionRespond(void);


void ICACHE_FLASH_ATTR
rfrtRegistNormalResponCallback(void (*normalResponCB)(void))
{
    rfrtNormalRespon.rfrtNormalResponCB = normalResponCB;
}

void ICACHE_FLASH_ATTR
rfrtRegistLearnCallback(void (*learnCB)(RfrtInfoFrame))
{
    rfrtLearn.rfrtLearnOkCB = learnCB;
}

void ICACHE_FLASH_ATTR
rfrtRegistTimeoutCallback(void (*timeoutCB)(void))
{
    rfrtTimeOut.rfrtTimeOutCB = timeoutCB;
}

void ICACHE_FLASH_ATTR
rfrtRegistRecvKeyValueCallback(void (*recvKeyValueCB)(RfrtInfoFrame))
{
    rfrtRecvKeyValue.rfrtRecvValueCB = recvKeyValueCB;
}

LOCAL uint16 ICACHE_FLASH_ATTR
rfrtGetFifoUsedBlock(void)
{
    return (fifoBuffer.fifoBuffSize + fifoBuffer.inPos - fifoBuffer.outPos)%fifoBuffer.fifoBuffSize;
}

/*-1 means the block before Outpos is not allowed to write*/
LOCAL uint16 ICACHE_FLASH_ATTR
rfrtGetFifoFreeBlock(void)
{
    return (fifoBuffer.fifoBuffSize - rfrtGetFifoUsedBlock()-1);
}

LOCAL uint8 
rfrtReadFifoUsedBlock(uint16 outpos)
{
    uint8 value =0;
    if(outpos> fifoBuffer.fifoBuffSize-1)return 0xff;
    if(fifoBuffer.inPos == outpos)
    {
      return 0xff;
    }
    else 
    {     
      value = fifoBuffer.pFifoBuff[outpos];
      return value;
    }    
}

LOCAL void 
rfrtWriteFifoFreeBlock(uint8 data)
{
    uint16 next_write_index = (uint16)(fifoBuffer.inPos + 1) % fifoBuffer.fifoBuffSize;
    if (next_write_index != fifoBuffer.outPos) 
    {
        fifoBuffer.pFifoBuff[fifoBuffer.inPos] = data;
        fifoBuffer.inPos = next_write_index;
    } 
}

LOCAL void ICACHE_FLASH_ATTR
rfrtFifoBufClr(void)
{
    fifoBuffer.outPos = fifoBuffer.inPos;
}

void ICACHE_FLASH_ATTR
rfrtInit(void)
{				
    fifoBuffer.fifoBuffSize = FIFOLEN; 
    fifoBuffer.inPos        = 0;     
    fifoBuffer.outPos       = 0;
}

/*
 *return 0xFF stand for error frame
 *
 */
LOCAL uint8 ICACHE_FLASH_ATTR
rfrtGetFrameLen(uint8 frametype)
{
    uint8 cnt = 0;
    for(cnt=0; cnt< MAX_FRAME_TYPE; cnt++)
    {
      if(rfrtFrameProp[cnt].frameType ==frametype)
      {
        return rfrtFrameProp[cnt].framelength;
      }
    }
    return 0xFF;    
}

LOCAL void ICACHE_FLASH_ATTR
rfrtAnalysisFrame(uint8* dataptr,uint16 datalen)
{
    RfrtInfoFrame  infoframe;
    infoframe.actType = dataptr[1] ;
	switch( infoframe.actType)
	{
	  case RFRT_TIMEOUT:
		rfrtActionRespond();
		if(rfrtTimeOut.rfrtTimeOutCB)
		{
		  (rfrtTimeOut.rfrtTimeOutCB)();
		}
		break;
	  case RFRT_LEARN_OK:
		rfrtActionRespond();
		infoframe.tysn         = (dataptr[2]<<8) + dataptr[3];
		infoframe.tlow         = (dataptr[4]<<8) + dataptr[5];
		infoframe.thigh        = (dataptr[6]<<8) + dataptr[7];
		infoframe.dataArrar[0] =  dataptr[8];
		infoframe.dataArrar[1] =  dataptr[9];
		infoframe.dataArrar[2] =  dataptr[10];
		if(rfrtLearn.rfrtLearnOkCB)
		{
		  (rfrtLearn.rfrtLearnOkCB)(infoframe);
		}
		break;
      case RFRT_UPLOAD:
		rfrtActionRespond();
		infoframe.tysn         = (dataptr[2]<<8) + dataptr[3];
		infoframe.tlow         = (dataptr[4]<<8) + dataptr[5];
		infoframe.thigh        = (dataptr[6]<<8) + dataptr[7];
		infoframe.dataArrar[0] =  dataptr[8];
		infoframe.dataArrar[1] =  dataptr[9];
		infoframe.dataArrar[2] =  dataptr[10];
		if(rfrtRecvKeyValue.rfrtRecvValueCB)
		{
		  (rfrtRecvKeyValue.rfrtRecvValueCB)(infoframe);
		}
		break;
	  case RFRT_RETURN_RESPOND:
	    if(rfrtNormalRespon.rfrtNormalResponCB)
	    {
		  (rfrtNormalRespon.rfrtNormalResponCB)();
		}
		break;
	  default:
		break;		
	}        
}

void ICACHE_FLASH_ATTR
rfrtLearnAction(void)
{
    uint8 len = 3;
    uint8 sendStr[3];
	sendStr[0] = FRAME_HEAD;
	sendStr[1] = RFRT_LEARN_CMD;
	sendStr[2] = FRAME_TAIL;
	uart0_tx_buffer(sendStr, len);

}

LOCAL void ICACHE_FLASH_ATTR
rfrtActionRespond(void)
{
    uint8 len =3;
    uint8 sendStr[3];
	sendStr[0] = FRAME_HEAD;
	sendStr[1] = RFRT_RETURN_RESPOND;
	sendStr[2] = FRAME_TAIL;
	uart0_tx_buffer(sendStr, len);
}


void ICACHE_FLASH_ATTR
rfrtEmitKeyValue(RfrtInfoFrame infoFrame)
{
	uint8 len;
	uint8 sendStr[12];
	if(infoFrame.actType != RFRT_EMIT_VALUE)return;	 	
	len = 12;
	sendStr[0]  =  FRAME_HEAD;
	sendStr[1]  =  infoFrame.actType;
	sendStr[2]  =  infoFrame.tysn>>8;
	sendStr[3]  =  infoFrame.tysn&0x00ff;
	sendStr[4]  =  infoFrame.tlow>>8;
	sendStr[5]  =  infoFrame.tlow&0x00ff;
	sendStr[6]  =  infoFrame.thigh>>8;
	sendStr[7]  =  infoFrame.thigh&0x00ff;
	sendStr[8]  =  infoFrame.dataArrar[0];
	sendStr[9]  =  infoFrame.dataArrar[1];
	sendStr[10] =  infoFrame.dataArrar[2];    
	sendStr[11] =  FRAME_TAIL;
	uart0_tx_buffer(sendStr, len);    
}


LOCAL bool ICACHE_FLASH_ATTR
rfrtAddDataToFifo(uint8* pdata, uint16 datalen)
{   
	if(pdata ==(void*)0)              return false ;
	if(datalen==0)                    return false ;	   
	if(rfrtGetFifoFreeBlock()<datalen)return false;	   
	while(datalen--)
	{
	  rfrtWriteFifoFreeBlock(*(pdata++));
	}
	return true;  
}

/* Check whether the str is correct, 
 * correct return the frame lenth
 * Incorrect include two condition:
 * 1. format error :return 0xff
 * 2. the frame is incomplete,but format uncertain return 0;
 * the follow if-trem cannot exchange position, with logic.
 */
LOCAL uint8 ICACHE_FLASH_ATTR
rfrtCheckCorrectFrame(uint8*str,uint16 remainSpc)
{ 
	uint16 len = 0;
	if(*str != FRAME_HEAD)return 0xFF;
	if(remainSpc<2) return 0; 
	len =rfrtGetFrameLen(str[1]); 
	if(len ==0xFF)return 0xFF;
	if(remainSpc<len) return 0;
	if(str[len -1] == FRAME_TAIL)return len;
	return 0xFF;
}



LOCAL uint8* ICACHE_FLASH_ATTR
rfrtStrChr (uint8*str,uint16 strlen,uint8 chr)
{
	while(strlen--)
	{
	  if(*str == chr)
	  {
	    return str;
	  }
	  str++;
	}
	return NULL;
}


/** 
 * Receive data and put it in the fifobuff,
 * then search the whole data area find out the correct frame
 */
void ICACHE_FLASH_ATTR 
rfrtDealRecvUartData(uint8*pdata,uint16 datalen)
{
	extern rfrtBuff fifoBuffer;   
	uint16 cnt            = 0; 
	uint16 len            = 0;
	uint16 fifoUsedNum    = 0;  
	uint16 outpos_t       = 0;
	uint8  *findOutPtr    = NULL;
	uint8  *copyPtr       = NULL;
	uint8  *copyPtrOrgi   = NULL;

	/**
	 * copy the fifobuff data to another buffer
	 */	   
    if( false  == rfrtAddDataToFifo(pdata,datalen) ) return; /*Receive data and put it in the buffer*/
    fifoUsedNum = rfrtGetFifoUsedBlock();                       
    copyPtrOrgi = (uint8*)os_malloc(fifoUsedNum+1);   /* one more space avoid point overflow*/
    copyPtr     = copyPtrOrgi;                                                    
    outpos_t    = fifoBuffer.outPos;
    os_memset(copyPtr, 0, fifoUsedNum);              
    for(cnt=0;cnt<fifoUsedNum;cnt++)                  
    {
      *(copyPtr+cnt) = rfrtReadFifoUsedBlock(outpos_t);
      outpos_t = (uint16)(outpos_t+1)%fifoBuffer.fifoBuffSize;
    } 

    /**
	 * search the buffer for remote frame,and annlysis
	 */	
    while(1)
    {  
	  findOutPtr = rfrtStrChr(copyPtr,fifoUsedNum,FRAME_HEAD); /*search for FRAME_HEAD*/
	  if(findOutPtr != NULL)
	  {       
	    fifoBuffer.outPos = (fifoBuffer.outPos + (findOutPtr - copyPtr))
	                         %fifoBuffer.fifoBuffSize;
	    fifoUsedNum -= (findOutPtr - copyPtr); 
		copyPtr = findOutPtr;                    /*ptr jump to the frame_head point*/
	  }else                                      
	  {
	     rfrtFifoBufClr();break;                 /*fifo without FRAME_HEAD,stop search;*/
	  }
	  len = rfrtCheckCorrectFrame(copyPtr,fifoUsedNum);
	  if(len == 0xFF)                            /* error frame,go to nxet position for next research*/
	  {
	    fifoBuffer.outPos = (fifoBuffer.outPos + 1)%fifoBuffer.fifoBuffSize;
	    fifoUsedNum -= 1;
		copyPtr +=1; 
	  }
	  else if(len == 0)                          /*correct frame but not complete,hold on*/
	  {
	    break;
	  }
	  else                                       /*correct frame*/
	  {
	    fifoBuffer.outPos = (fifoBuffer.outPos + len)%fifoBuffer.fifoBuffSize;
	    fifoUsedNum -= len;
	    rfrtAnalysisFrame(copyPtr,len);       
		copyPtr += len;                          /*jump out of the error frame*/
	  }
    }
    os_free(copyPtrOrgi);	
}




