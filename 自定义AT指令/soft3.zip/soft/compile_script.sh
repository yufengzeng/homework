#!/bin/bash

rm -r build
make CT_PRODUCT=st86 APART=1