#ifndef __ZZ_GLOBAL_H__
#define __ZZ_GLOBAL_H__

#include "sl_type.h"

extern SL_TASK zz_app_mtask;
extern SL_TASK zz_app_htask;

#endif /* __ZZ_GLOBAL_H__ */

