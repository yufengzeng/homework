#ifndef __ZZ_MEM_H__
#define __ZZ_MEM_H__

#include "sl_memory.h"

#define zzMemzero(p, len)               SL_Memset((p), 0, (len))

#endif /* __ZZ_MEM_H__ */

